//javascript goes here

// keep variables organized at the top of the script
var today = new Date();
var hourNow = today.getHours();
var greeting;
var message = document.getElementById("message");

//this shows the variables in the Inspector Console
console.log(today);
console.log(hourNow);

//This adds an h3 to the end of our HTML
// document.write(`<h3>${today}</h3>`);

if (hourNow >= 18) {
	greeting = "Good Evening";
} else if (hourNow >= 12) {
	greeting = "Good Afternoon";
} else if (hourNow >= 5) {
	greeting = "Good Morning";
} else {
	greeting = "Welcome";
};

// document.write(`<h3>${greeting}</h3>`);

message.innerHTML = greeting;

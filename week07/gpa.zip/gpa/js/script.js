var gpa = [];
var total = 0;
var courses = document.getElementById("courses");
var displayTotal = document.getElementById("total");

function calculateGPA() {
    
    //gets grade from input field
    grade = parseInt(document.getElementById("grade").value);
    if (isNaN(grade)){
        //evalutes grade for entries that are not a number
        return;
    }
    
    //evaluates grade to assign GPA value to array
    if (grade < 50) {
        gpa.push(0); 
    } else if (grade < 55 ) {
        gpa.push(1); 
    } else if (grade < 60 ) {
        gpa.push(1.5); 
    } else if (grade < 65 ) {
        gpa.push(2); 
    } else if (grade < 70 ) {
        gpa.push(2.5); 
    } else if (grade < 75 ) {
        gpa.push(3); 
    } else if (grade < 80 ) {
        gpa.push(3.3); 
    } else if (grade < 85 ) {
        gpa.push(3.6); 
    } else if (grade < 90 ) {
        gpa.push(3.8); 
    } else if (grade < 100 ) {
        gpa.push(4); 
    } else if (grade > 100 ) {
        console.log("You can't get over 100");
        //kills the function so displayGPA and calcTotal aren't run with bad value
        return;
    };
    
    displayGPA();
    calcTotal();
};

function displayGPA(){
    // creates a new li
    var course = document.createElement("li");
    // fills the li with GPA info
    course.innerHTML = `Course ${gpa.length} GPA: ${gpa[gpa.length-1]}`;
    // adds it to the courses ul
    courses.appendChild(course);
};

function calcTotal(){
    //calculates total
    total = total + gpa[gpa.length-1];
    //displays total
    displayTotal.innerHTML = `Total GPA: ${(total / gpa.length).toFixed(1)}`;
    //changes color based on probationary status
    if (total < 2 ) {
        displayTotal.style.color = "red";
    } else {
        displayTotal.style.color = "green";
    };
};

document.getElementById("button").addEventListener("click", calculateGPA);
// This is not the most efficient way to code this solution
// This example is to point out errors for debugging

console.log("Hey, my main.js file is up and running!");

var btn = document.getElementById("calculate");

function getNumbers(){
    var width = document.getElementById("width");
    var height = document.getElementById("height");
    
    calculatePerimeter();   
}

function calculate(){
    total = width + height + width + height;
    document.getElementById("result").innerHTML = '${total} m';
}

btn.addEventListener("click", getnumbers);
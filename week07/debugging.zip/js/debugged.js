// This is not the most efficient way to code this solution
// This example is to point out errors for debugging

console.log("Hey, my main.js file is up and running!");

var btn = document.getElementById("calculate");

function getNumbers(){
    var width = document.getElementById("width").value;
    var height = document.getElementById("height").value;   

    calculatePerimeter(width, height);   
}

function calculatePerimeter(width, height){
    console.warn('calculatePerimeter is working!');
    width = Number(width);
    height = Number(height);
    var total = (width + height) * 2;
    console.error(typeof total);

    document.getElementById("result").innerHTML = `${total} m`;
}

btn.addEventListener("click", getNumbers);
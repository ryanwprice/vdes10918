console.log("Hey, my main.js file is up and running!");

// CODE GOES HERE
var wheel = document.getElementById("wheel");
var arrow = document.getElementById("arrow");

var angle = 7;

function spin(){  
	var deg = Math.ceil(Math.random() * 24) * 15;        
	angle += deg;
	wheel.style.transform = `rotate(${angle}deg)`;
};

arrow.addEventListener("click", spin);
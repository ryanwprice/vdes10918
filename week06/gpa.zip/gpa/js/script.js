var gpa = 0;
var total = 0;
var courseCount = 0;
var courses = document.getElementById("courses");
var displayTotal = document.getElementById("total");

function calculateGPA() {
    
    //gets grade from input field
    grade = parseInt(document.getElementById("grade").value);
    if (isNaN(grade)){
        //evalutes grade for entries that are not a number
        return;
    }
    
    //evaluates grade to assign GPA value
    if (grade < 50) {
        gpa = 0; 
		courseCount++;
    } else if (grade < 55 ) {
        gpa = 1; 
		courseCount++;
    } else if (grade < 60 ) {
        gpa = 1.5; 
		courseCount++;
    } else if (grade < 65 ) {
        gpa = 2; 
		courseCount++;
    } else if (grade < 70 ) {
        gpa = 2.5; 
		courseCount++;
    } else if (grade < 75 ) {
        gpa = 3; 
		courseCount++;
    } else if (grade < 80 ) {
        gpa = 3.3; 
		courseCount++;
    } else if (grade < 85 ) {
        gpa = 3.6;
		courseCount++;
    } else if (grade < 90 ) {
        gpa = 3.8;
		courseCount++;
    } else if (grade < 100 ) {
        gpa = 4; 
		courseCount++;
    } else if (grade > 100 ) {
        console.log("You can't get over 100");
        alert("Nice try ;)");
        //kills the function so displayGPA and calcTotal aren't run with bad value
        return;
    };
    
    displayGPA();
    calcTotal();
};

function displayGPA(){
    // creates a new li
    var course = document.createElement("li");
    // fills the li with GPA info
    course.innerHTML = `Course ${courseCount} &mdash\; GPA: ${gpa}`;
    // adds it to the courses ul
    courses.appendChild(course);
};

function calcTotal(){
    //calculates total
    total = total + gpa;
    //displays total
    displayTotal.innerHTML = `Total GPA: ${(total / courseCount).toFixed(1)}`;
    //changes color based on probationary status
    if (total < 2 ) {
        displayTotal.style.color = "red";
    } else {
        displayTotal.style.color = "green";
    };
};

document.getElementById("button").addEventListener("click", calculateGPA);
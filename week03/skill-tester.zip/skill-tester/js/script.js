// This is where you JS goes

// listen for a click of the  button

// get the value of the input

// evaluate the input value to see if it is correct
// You can use JS to do the math for you ;)

// Display the answer

// Change the colour of the answer depending on whether it is correct or not

// Add an animation if the answer is correct!